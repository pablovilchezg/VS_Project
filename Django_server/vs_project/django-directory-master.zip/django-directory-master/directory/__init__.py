"""Copyright Askbot SpA 2014, Licensed under GPLv3 license.

Django directory module, allowing authorized users to list
files in a given directory and download them"""
